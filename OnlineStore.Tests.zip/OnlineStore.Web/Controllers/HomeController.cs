﻿using Microsoft.AspNetCore.Mvc;
using OnlineStore.ViewModels;
using System.Diagnostics;

namespace OnlineStore.Web.Controllers
{
    public class HomeController : BaseController
    {
          [HttpGet]
          public IActionResult Index()
          {
              try
              {
                  if (IsUserAuthenticated())
                  {
                      return RedirectToAction(nameof(Index), "Product");
                  }
                  return View();
              }
              catch (Exception ex)
              {
                  Console.WriteLine(ex.Message);
                  return View("Error"); // Покажи Error View вместо да пренасочваш пак към Index
              }
          }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
