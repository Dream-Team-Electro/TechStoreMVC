﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OnlineStore.Services.Core.Contracts;
using OnlineStore.ViewModels.Product;

using System.Globalization;
using static OnlineStore.GCommon.ValidationConstants.Product;
namespace OnlineStore.Web.Controllers
{
    public class ProductController : BaseController
    {
        private readonly IProductService _IProductService;
        private readonly ICategoryService _ICategoryService;
        public ProductController(IProductService iproductService, ICategoryService iCategoryService)
        {
            _IProductService = iproductService;
            _ICategoryService = iCategoryService;
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            try
            {
                string userId = this.GetUserId();
                IEnumerable<ProductIndexViewModel> allRecipes = await this._IProductService.GetAllProductsAsync(userId);
                return this.View(allRecipes);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return this.RedirectToAction(nameof(Index), "Home");
            }
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            try
            {
                CreateProductInputModel addRecipeInputModel = new CreateProductInputModel()
                {
                    CreatedOn = DateTime.UtcNow.ToString(CreatedOnFormat, CultureInfo.InvariantCulture),
                    Categories = await _ICategoryService.GetCategoriesDropDownAsync(),
                };

                return this.View(addRecipeInputModel);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return this.RedirectToAction(nameof(Index));
            }
        }
        [HttpPost]
        public async Task<IActionResult> Create(CreateProductInputModel inputModel)
        {
            try
            {
                if (!this.ModelState.IsValid)
                {
                    inputModel.Categories = await _ICategoryService.GetCategoriesDropDownAsync();
                    return this.View(inputModel);
                }
                bool addResult = await this._IProductService.CreateProductAsync(this.GetUserId(), inputModel);

                if (addResult == false)
                {
                    ModelState.AddModelError(string.Empty, "Fatal error occurred while Creating a Product");
                    inputModel.Categories = await _ICategoryService.GetCategoriesDropDownAsync();
                    return this.View(inputModel);
                }

                return this.RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return this.RedirectToAction(nameof(Index));
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> Details(int? id)
        {
            try
            {
                string? userId = this.GetUserId();
                DetailsProductViewModel recipeDetails = await this._IProductService.GetProductDetailsAsync(userId, id);
                if (recipeDetails == null)
                {
                    return this.RedirectToAction(nameof(Index));
                }
                return this.View(recipeDetails);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return this.RedirectToAction(nameof(Index));
            }
        }

        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                string? userId = this.GetUserId();
                DeleteProductInputModel? deleteRecipeInputModel = await this._IProductService.GetProductForDeletingAsync(userId, id);
                if (deleteRecipeInputModel == null)
                {
                    return this.RedirectToAction(nameof(Index));
                }
                return this.View(deleteRecipeInputModel);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return this.RedirectToAction(nameof(Index));
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmDelete(DeleteProductInputModel inputModel)
        {
            try
            {
                if (!this.ModelState.IsValid)
                {
                    ModelState.AddModelError(string.Empty, "Please do not modify the page!");
                    return this.View(inputModel);
                }
                bool deleteResult = await this._IProductService.SoftDeleteProductAsync(this.GetUserId()!, inputModel);

                if (deleteResult == false)
                {
                    ModelState.AddModelError(string.Empty, "Fatal error occurred while deleting the recipe!");
                    return this.View(inputModel);
                }
                return this.RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return this.RedirectToAction(nameof(Index));
            }

        }

        [HttpGet]
        public async Task<IActionResult> Edit(int? id)
        {
            try
            {
                string userId = this.GetUserId()!;
                EditProductInputModel? editRecipeInputModel = await this._IProductService.GetProductForEditingAsync(userId, id);
                if (editRecipeInputModel == null)
                {
                    return this.RedirectToAction(nameof(Index));
                }

                editRecipeInputModel.Categories = await _ICategoryService.GetCategoriesDropDownAsync();

                return this.View(editRecipeInputModel);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return this.RedirectToAction(nameof(Index));
            }
        }

        [HttpPost]
        public async Task<IActionResult> Edit(EditProductInputModel inputModel)
        {
            try
            {
                if (!this.ModelState.IsValid)
                {
                    return this.View(inputModel);
                }
                bool editResult = await this._IProductService.PersistUpdatedProductAsync(this.GetUserId()!, inputModel);

                if (editResult == false)
                {
                    this.ModelState.AddModelError(string.Empty, "Fatal error occurred while updating the Product!");
                    return this.View(inputModel);
                }
                return this.RedirectToAction(nameof(Details), new { id = inputModel.Id });
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return this.RedirectToAction(nameof(Index));
            }
        }

        [HttpGet]
        public async Task<IActionResult> ShoppingCart()
        {
            try
            {
                string? userId = this.GetUserId();
                IEnumerable<FavoriteProductViewModel> favoriteRecipes = await this._IProductService.GetFavoriteProductsAsync(userId);
                if(favoriteRecipes == null)
                {
                    return this.RedirectToAction(nameof(Index));
                }
                return this.View(favoriteRecipes);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return this.RedirectToAction(nameof(Index));
            }
        }

        [HttpPost]
        public async Task<IActionResult> Save(int? id)
        {
            try
            {
                string userId = this.GetUserId()!;

                if (id == null)
                {
                    return this.RedirectToAction(nameof(Index));
                }

                bool favAddResult = await this._IProductService.AddProductToUserFavoritesListAsync(userId, id.Value);

                if (favAddResult == false)
                {
                    return this.RedirectToAction(nameof(Index));
                }

                return this.RedirectToAction(nameof(ShoppingCart));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return this.RedirectToAction(nameof(Index));
            }
        }

        [HttpPost]
        public async Task<IActionResult> Remove(int? id)
        {
            try
            {
                string userId = this.GetUserId()!;

                if (id == null)
                {
                    return this.RedirectToAction(nameof(Index));
                }

                bool favRemoveResult = await this._IProductService.RemoveProductFromUserFavoritesListAsync(userId, id.Value);

                if (favRemoveResult == false)
                {
                    return this.RedirectToAction(nameof(Index));
                }

                return this.RedirectToAction(nameof(ShoppingCart));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return this.RedirectToAction(nameof(Index));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Buy(int id)
        {
            try
            {
                string userId = this.GetUserId()!;

                // Тук добави логика за закупуване на продукта с id:
                // Например, извикване на съответен метод от _IProductService,
                // който ще обработи поръчката.

                bool purchaseResult = await _IProductService.PurchaseProductAsync(userId, id);

                if (!purchaseResult)
                {
                    // Може да върнеш грешка с подробности, ако искаш
                    return BadRequest("Purchase failed.");
                }

                return Ok();  // връща 200 OK, ако е успешно
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return StatusCode(500, "Internal server error");
            }
        }

    }
}