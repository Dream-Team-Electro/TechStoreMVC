﻿using Microsoft.AspNetCore.Identity;
using OnlineStore.Data.Models;

namespace OnlineStore.Data.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string Title { get; set; } = null!;
        public string Description { get; set; } = null!;
        public string? ImageUrl { get; set; }
        public DateTime CreatedOn { get; set; }
        public string AuthorId { get; set; } = null!;
        public virtual IdentityUser Author { get; set; } = null!;
        public int CategoryId { get; set; }
        public virtual Category Category { get; set; } = null!;
        public bool IsDeleted { get; set; }
        public virtual IEnumerable<UserProduct> UsersProducts { get; set; } = new List<UserProduct>();
     
    }
}

