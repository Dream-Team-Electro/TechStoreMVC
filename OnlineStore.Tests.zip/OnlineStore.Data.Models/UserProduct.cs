﻿using Microsoft.AspNetCore.Identity;

namespace OnlineStore.Data.Models
{
    public class UserProduct
    {
        public string UserId { get; set; } = null!;
        public virtual IdentityUser User { get; set; } = null!;

        public int ProductId { get; set; }
        public virtual Product Product { get; set; } = null!;
    }
}