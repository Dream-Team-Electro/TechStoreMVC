﻿
using OnlineStore.ViewModels.Product;


namespace OnlineStore.Services.Core.Contracts
{
    public interface ICategoryService
    {
        Task<IEnumerable<AddCategoryDropDownModel>> GetCategoriesDropDownAsync();
    }
}
