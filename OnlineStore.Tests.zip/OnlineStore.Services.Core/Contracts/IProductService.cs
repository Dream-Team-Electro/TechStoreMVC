﻿

using OnlineStore.ViewModels.Product;

namespace OnlineStore.Services.Core.Contracts
{
    public interface IProductService
    {
        Task<IEnumerable<ProductIndexViewModel>> GetAllProductsAsync(string? userId);
        Task<bool> CreateProductAsync (string? userId,CreateProductInputModel inputModel);

        Task<DetailsProductViewModel> GetProductDetailsAsync(string userId,int? id);

        Task<DeleteProductInputModel> GetProductForDeletingAsync(string? userId,int id);
        Task<bool> SoftDeleteProductAsync(string userId, DeleteProductInputModel inputModel);

        Task<EditProductInputModel> GetProductForEditingAsync(string userId, int? id); 
        Task<bool> PersistUpdatedProductAsync(string userId, EditProductInputModel inputModel);

        Task<IEnumerable<FavoriteProductViewModel>> GetFavoriteProductsAsync(string userId);
        Task<bool> AddProductToUserFavoritesListAsync(string userId, int id);

        Task<bool> RemoveProductFromUserFavoritesListAsync(string userId, int id);

        Task<bool> PurchaseProductAsync(string userId, int id);

    }
}
