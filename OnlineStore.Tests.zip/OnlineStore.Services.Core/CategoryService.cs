﻿using Microsoft.EntityFrameworkCore;
using OnlineStore.Data;
using OnlineStore.Services.Core.Contracts;
using OnlineStore.ViewModels.Product;

namespace OnlineStore.Services.Core
{
    public class CategoryService : ICategoryService
    {
        private readonly ApplicationDbContext _dbContext;
        public CategoryService(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<IEnumerable<AddCategoryDropDownModel>> GetCategoriesDropDownAsync()
        {
            IEnumerable<AddCategoryDropDownModel> addCategoryDropDowns = await _dbContext.Categories
                .AsNoTracking()
                .Select(c => new AddCategoryDropDownModel()
                {
                    Id = c.Id,
                    Name = c.Name
                })
                 .ToArrayAsync();

            return addCategoryDropDowns;
        }


    }
}
