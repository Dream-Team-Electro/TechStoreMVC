﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using OnlineStore.Data.Models;
using OnlineStore.ViewModels.Product;
using OnlineStore.Data;
using OnlineStore.Services.Core.Contracts;
using System.Globalization;
using static OnlineStore.GCommon.ValidationConstants.Product;
namespace OnlineStore.Services.Core
{
    public class ProductService : IProductService
    {
        private readonly ApplicationDbContext _applicationDbContext;
        private readonly UserManager<IdentityUser> _userManager;
        public ProductService(ApplicationDbContext applicationDbContext, UserManager<IdentityUser> userManager)
        {
            _applicationDbContext = applicationDbContext;
            this._userManager = userManager;
        }
        public async Task<IEnumerable<ProductIndexViewModel>> GetAllProductsAsync(string? userId)
        {
            IEnumerable<ProductIndexViewModel> recipes = await _applicationDbContext.Products
                  .Include(r => r.Category)
                  .Include(r => r.UsersProducts)
                  .AsNoTracking()
                  .Select(r => new ProductIndexViewModel()
                  {
                      Id = r.Id,
                      Title = r.Title,
                      ImageUrl = r.ImageUrl,
                      Category = r.Category.Name,
                      SavedCount = r.UsersProducts.Count(),
                      IsAuthor = userId != null ? r.AuthorId.ToLower() == userId.ToLower() : false,
                      IsSaved = userId != null ? r.UsersProducts.Any(ur => ur.UserId.ToLower() == userId.ToLower()) : false

                  })
                .ToArrayAsync();

            return recipes;
        }

        public async Task<bool> CreateProductAsync(string? userId,CreateProductInputModel inputModel)
        {
            bool opResult = false;
            IdentityUser? user = await this._userManager.FindByIdAsync(userId);
            Category? category = await _applicationDbContext.Categories.FindAsync(inputModel.CategoryId);

            bool isCreatedOnValid = DateTime.TryParseExact(inputModel.CreatedOn, CreatedOnFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime createdOn);

            if(user != null && category != null && isCreatedOnValid)
            {
                Product Newrecipe = new Product()
                {
                    Title = inputModel.Title,
                    Description = inputModel.Description,
                    ImageUrl = inputModel.ImageUrl,
                    AuthorId = user.Id,
                    Author = user,
                    CreatedOn = createdOn,
                    CategoryId = category.Id,
                    Category = category
                };
                await _applicationDbContext.Products.AddAsync(Newrecipe);
                await _applicationDbContext.SaveChangesAsync();

                opResult = true;
            }
            return opResult;
        } //DONE

        public async Task<DeleteProductInputModel> GetProductForDeletingAsync(string? userId, int id)
        {
            bool opResult = false;

            DeleteProductInputModel? deleteModel = null;

            if (id != null)
            {
                Product? DeleteRecipeModel = await _applicationDbContext
                    .Products
                    .Include(r => r.Author)
                   .AsNoTracking()
                   .SingleOrDefaultAsync(r => r.Id == id);

                if(DeleteRecipeModel != null && DeleteRecipeModel.AuthorId.ToLower() == userId.ToLower())
                {
                    deleteModel = new DeleteProductInputModel()
                    {
                        Id= DeleteRecipeModel.Id,
                        Title = DeleteRecipeModel.Title,
                        Author = DeleteRecipeModel.Author.UserName,
                        AuthorId = DeleteRecipeModel.AuthorId
                    };
                }
            }
            return deleteModel;
        } //DONE

        public async Task<bool> SoftDeleteProductAsync(string userId, DeleteProductInputModel inputModel)
        {
            bool opResult = false;

            IdentityUser? user = await this._userManager.FindByIdAsync(userId);

            Product? recipe = await _applicationDbContext
                .Products.FindAsync(inputModel.Id);

            if (user != null && recipe != null && recipe.AuthorId.ToLower() == userId.ToLower()) 
            {
                recipe.IsDeleted = true;

                await this._applicationDbContext.SaveChangesAsync();
                opResult = true;
            }

            return opResult;
        } //DONE

        public async Task<DetailsProductViewModel>GetProductDetailsAsync(string userId, int? id)
        {
            DetailsProductViewModel? detailsRecipeVm = null;

            if (id.HasValue)
            {
                Product? recipe = await _applicationDbContext.Products
                    .Include(r => r.Category)
                    .Include(r => r.UsersProducts)
                    .Include(r => r.Author)
                    .AsNoTracking()
                    .FirstOrDefaultAsync(r => r.Id == id.Value);
                if(recipe != null)
                {
                    detailsRecipeVm = new DetailsProductViewModel()
                    {
                        Id = recipe.Id,
                        Title = recipe.Title,
                        ImageUrl = recipe.ImageUrl,
                        Category = recipe.Category.Name,
                        IsAuthor = userId != null ? recipe.AuthorId.ToLower() == userId.ToLower() : false,
                        IsSaved = recipe.UsersProducts.Any(ur => userId != null ? ur.UserId.ToLower() == userId.ToLower() : false),
                        Instructions = recipe.Description,
                        CreatedOn = recipe.CreatedOn.ToString(CreatedOnFormat, CultureInfo.InvariantCulture),
                        Author = recipe.Author.UserName
                    };
                    
                }
            }
            return detailsRecipeVm;
        }//DONE

        public async Task<EditProductInputModel> GetProductForEditingAsync(string userId, int? id)
        {
            EditProductInputModel? editModel = null;

                if (id != null)
                {
                Product? recipeToEdit = await this._applicationDbContext.Products
                    .AsNoTracking() 
                    .SingleOrDefaultAsync(r =>r.Id == id);

                     if (recipeToEdit != null && recipeToEdit.AuthorId.ToLower() == userId.ToLower())
                     {
                         editModel = new EditProductInputModel()
                         {
                             Id = recipeToEdit.Id,
                             Title = recipeToEdit.Title,
                             Description = recipeToEdit.Description,
                             ImageUrl = recipeToEdit.ImageUrl,
                             CreatedOn = recipeToEdit.CreatedOn.ToString(CreatedOnFormat, CultureInfo.InvariantCulture),
                             CategoryId = recipeToEdit.CategoryId,
                             Categories = await _applicationDbContext.Categories
                                 .Select(c => new AddCategoryDropDownModel()
                                 {
                                     Id = c.Id,
                                     Name = c.Name
                                 })
                                 .ToListAsync()
                         };
                     }

                }
                 return editModel;
        }//DONE

        public async Task<bool> PersistUpdatedProductAsync(string userId, EditProductInputModel inputModel)
        {
            bool opResult = false;
            IdentityUser? user = await this._userManager.FindByIdAsync(userId);

            Product? updatedRecipe = await this._applicationDbContext
                .Products
                .FindAsync(inputModel.Id);

            Category? categoryRef = await this._applicationDbContext
             .Categories
             .FindAsync(inputModel.CategoryId);

            bool isPublishedOnDateValid = DateTime
                   .TryParseExact(inputModel.CreatedOn, CreatedOnFormat, CultureInfo.InvariantCulture,
                       DateTimeStyles.None, out DateTime publishedOnDate);

            if (user != null && categoryRef != null && updatedRecipe != null
                && isPublishedOnDateValid && updatedRecipe.AuthorId.ToLower() == userId.ToLower())
            {
                updatedRecipe.Title = inputModel.Title;
                updatedRecipe.Description = inputModel.Description;
                updatedRecipe.ImageUrl = inputModel.ImageUrl;
                updatedRecipe.CategoryId = categoryRef.Id;
                updatedRecipe.Category = categoryRef;
                updatedRecipe.CreatedOn = publishedOnDate;

               await this._applicationDbContext.SaveChangesAsync();
                opResult = true;
            }
            return opResult;
        }//DONE

        public async Task<IEnumerable<FavoriteProductViewModel>> GetFavoriteProductsAsync(string userId)
        {
            IEnumerable<FavoriteProductViewModel>? favRecipes = null;
            IdentityUser? user = await this._userManager.FindByIdAsync(userId);

            if (user != null)
            {
                favRecipes = await this._applicationDbContext
                    .UsersProducts
                    .Include(ur => ur.Product)
                    .ThenInclude(ur => ur.Category)
                    .AsNoTracking()
                     .Where(ur => ur.UserId.ToLower() == userId.ToLower())
                    .Select(ur => new FavoriteProductViewModel()
                    {
                        Id= ur.Product.Id,
                        Title = ur.Product.Title,
                        ImageUrl = ur.Product.ImageUrl,
                        Category = ur.Product.Category.Name
                        

                    })
                    .ToArrayAsync();
            }
            return favRecipes;
        }//DONE

        public async Task<bool> AddProductToUserFavoritesListAsync(string userId, int id)
        {
            bool opResult = false;

            IdentityUser? user = await this._userManager.FindByIdAsync(userId);

            Product? favRecipe = await this._applicationDbContext
                .Products
                .FindAsync(id);

            if (user != null && favRecipe != null &&
                favRecipe.AuthorId.ToLower() != userId.ToLower())
            {
                UserProduct? userFavRecipe = await this._applicationDbContext
                    .UsersProducts
                    .SingleOrDefaultAsync(ud => ud.UserId.ToLower() == userId && ud.ProductId == id);

                if (userFavRecipe == null)
                {
                    userFavRecipe = new UserProduct()
                    {
                        UserId = userId,
                        ProductId = id
                    };

                    await this._applicationDbContext.UsersProducts.AddAsync(userFavRecipe);
                    await this._applicationDbContext.SaveChangesAsync();

                    opResult = true;
                }
            }

            return opResult;
        }

        public async Task<bool> RemoveProductFromUserFavoritesListAsync(string userId, int id)
        {
            bool opResult = false;

            IdentityUser? user = await this._userManager.FindByIdAsync(userId);

            if (user != null)
            {
                UserProduct? userFavRecipe = await this._applicationDbContext
                    .UsersProducts
                    .SingleOrDefaultAsync(ud => ud.UserId.ToLower() == userId.ToLower() && ud.ProductId == id);

                if (userFavRecipe != null)
                {
                    this._applicationDbContext.UsersProducts.Remove(userFavRecipe);
                    await this._applicationDbContext.SaveChangesAsync();

                    opResult = true;
                }
            }

            return opResult;
        }

        public async Task<bool> PurchaseProductAsync(string userId, int id)
        {
            bool opResult = false;

            IdentityUser? user = await this._userManager.FindByIdAsync(userId);

            if (user != null)
            {
                UserProduct? userFavRecipe = await this._applicationDbContext
                    .UsersProducts
                    .SingleOrDefaultAsync(ud => ud.UserId.ToLower() == userId.ToLower() && ud.ProductId == id);

                if (userFavRecipe != null)
                {
                    this._applicationDbContext.UsersProducts.Remove(userFavRecipe);
                    await this._applicationDbContext.SaveChangesAsync();

                    opResult = true;
                }
            }

            return opResult;
        }
    } 
}