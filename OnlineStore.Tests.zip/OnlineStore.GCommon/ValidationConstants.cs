﻿namespace OnlineStore.GCommon
{
    public class ValidationConstants
    {
        public class Product
        {
            public const int TitleMaxLength = 50;
            public const int TitleMinLength = 3;
            public const int DescriptionMaxLength = 500;
            public const int DescriptionMinLength = 10;
            public const int ImageUrlMaxLength = 2048;
            public const string CreatedOnFormat = "yyyy-MM-dd";
            public const int CreatedOnLength = 10;
        }
        public class Category
        {
            public const int NameMaxLength = 20;
            public const int NameMinLength = 3;
        }
    }
}