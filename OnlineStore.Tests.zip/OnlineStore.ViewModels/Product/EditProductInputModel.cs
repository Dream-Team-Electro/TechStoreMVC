﻿using OnlineStore.ViewModels.Product;

namespace OnlineStore.ViewModels.Product
{
    public class EditProductInputModel
    {
        public int Id { get; set; }
        public string Title { get; set; } = null!;
        public string Description { get; set; } = null!;
        public string? ImageUrl { get; set; }
        public int CategoryId { get; set; }
        public string CreatedOn { get; set; } = null!;
        public IEnumerable<AddCategoryDropDownModel>? Categories { get; set; }
    }
}
