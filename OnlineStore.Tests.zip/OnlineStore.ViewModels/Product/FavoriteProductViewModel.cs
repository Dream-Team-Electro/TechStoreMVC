﻿namespace OnlineStore.ViewModels.Product
{
    public class FavoriteProductViewModel
    {
        public int Id { get; set; }
        public string Title { get; set; } = null!;
        public string? ImageUrl { get; set; }
        public string Category { get; set; } = null!; 
    }
}
