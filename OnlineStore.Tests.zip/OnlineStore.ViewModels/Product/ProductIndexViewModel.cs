﻿
namespace OnlineStore.ViewModels.Product
{
    public class ProductIndexViewModel : BaseInputModel
    {
            public int SavedCount { get; set; }

    }
}