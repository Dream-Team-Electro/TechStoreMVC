﻿
using System.ComponentModel.DataAnnotations;
using static OnlineStore.GCommon.ValidationConstants.Product;
namespace OnlineStore.ViewModels.Product
{
    public class CreateProductInputModel
    {
        [Required]
        [StringLength(TitleMaxLength, MinimumLength = TitleMinLength)]
        public string Title { get; set; } = null!;
        public int CategoryId { get; set; }
       

        [Required]
        [StringLength(DescriptionMaxLength, MinimumLength = DescriptionMinLength)]
        public string Description { get; set; } = null!;
        public string? ImageUrl { get; set; }

        [Required]
        [StringLength(CreatedOnLength, MinimumLength = CreatedOnLength)]
        public string CreatedOn { get; set; } = null!;

        public IEnumerable<AddCategoryDropDownModel>? Categories { get; set; }
    }
}



