﻿using NUnit.Framework;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;

using OnlineStore.Services.Core.Contracts;
using OnlineStore.ViewModels.Product;

namespace OnlineStore.Tests
{
    [TestFixture]
    public class ProductServiceSimpleTests
    {
        private Mock<IProductService> _mockService;

        [SetUp]
        public void Setup()
        {
            _mockService = new Mock<IProductService>();
        }

        [Test]
        public async Task GetAllProductsAsync_ReturnsEnumerable()
        {
            _mockService.Setup(s => s.GetAllProductsAsync(It.IsAny<string?>()))
                .ReturnsAsync(new List<ProductIndexViewModel> { new ProductIndexViewModel() });

            var result = await _mockService.Object.GetAllProductsAsync("userId");

            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.Not.Empty);
        }

        [Test]
        public async Task CreateProductAsync_ReturnsTrue()
        {
            _mockService.Setup(s => s.CreateProductAsync(It.IsAny<string?>(), It.IsAny<CreateProductInputModel>()))
                .ReturnsAsync(true);

            var result = await _mockService.Object.CreateProductAsync("userId", new CreateProductInputModel());

            Assert.That(result, Is.True);
        }

        [Test]
        public async Task GetProductDetailsAsync_ReturnsNotNull()
        {
            _mockService.Setup(s => s.GetProductDetailsAsync(It.IsAny<string>(), It.IsAny<int?>()))
                .ReturnsAsync(new DetailsProductViewModel());

            var result = await _mockService.Object.GetProductDetailsAsync("userId", 1);

            Assert.That(result, Is.Not.Null);
        }

        [Test]
        public async Task GetProductForDeletingAsync_ReturnsNotNull()
        {
            _mockService.Setup(s => s.GetProductForDeletingAsync(It.IsAny<string?>(), It.IsAny<int>()))
                .ReturnsAsync(new DeleteProductInputModel());

            var result = await _mockService.Object.GetProductForDeletingAsync("userId", 1);

            Assert.That(result, Is.Not.Null);
        }

        [Test]
        public async Task SoftDeleteProductAsync_ReturnsTrue()
        {
            _mockService.Setup(s => s.SoftDeleteProductAsync(It.IsAny<string>(), It.IsAny<DeleteProductInputModel>()))
                .ReturnsAsync(true);

            var result = await _mockService.Object.SoftDeleteProductAsync("userId", new DeleteProductInputModel());

            Assert.That(result, Is.True);
        }

        [Test]
        public async Task GetProductForEditingAsync_ReturnsNotNull()
        {
            _mockService.Setup(s => s.GetProductForEditingAsync(It.IsAny<string>(), It.IsAny<int?>()))
                .ReturnsAsync(new EditProductInputModel());

            var result = await _mockService.Object.GetProductForEditingAsync("userId", 1);

            Assert.That(result, Is.Not.Null);
        }

        [Test]
        public async Task PersistUpdatedProductAsync_ReturnsTrue()
        {
            _mockService.Setup(s => s.PersistUpdatedProductAsync(It.IsAny<string>(), It.IsAny<EditProductInputModel>()))
                .ReturnsAsync(true);

            var result = await _mockService.Object.PersistUpdatedProductAsync("userId", new EditProductInputModel());

            Assert.That(result, Is.True);
        }

        [Test]
        public async Task GetFavoriteProductsAsync_ReturnsEnumerable()
        {
            _mockService.Setup(s => s.GetFavoriteProductsAsync(It.IsAny<string>()))
                .ReturnsAsync(new List<FavoriteProductViewModel> { new FavoriteProductViewModel() });

            var result = await _mockService.Object.GetFavoriteProductsAsync("userId");

            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.Not.Empty);
        }

        [Test]
        public async Task AddProductToUserFavoritesListAsync_ReturnsTrue()
        {
            _mockService.Setup(s => s.AddProductToUserFavoritesListAsync(It.IsAny<string>(), It.IsAny<int>()))
                .ReturnsAsync(true);

            var result = await _mockService.Object.AddProductToUserFavoritesListAsync("userId", 1);

            Assert.That(result, Is.True);
        }

        [Test]
        public async Task RemoveProductFromUserFavoritesListAsync_ReturnsTrue()
        {
            _mockService.Setup(s => s.RemoveProductFromUserFavoritesListAsync(It.IsAny<string>(), It.IsAny<int>()))
                .ReturnsAsync(true);

            var result = await _mockService.Object.RemoveProductFromUserFavoritesListAsync("userId", 1);

            Assert.That(result, Is.True);
        }
    }
}
