﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OnlineStore.Data.Models;
using static OnlineStore.GCommon.ValidationConstants.Product;

namespace OnlineStore.Data.Configurations
{
    public class ProductConfiguration : IEntityTypeConfiguration<Product>
    {
        public void Configure(EntityTypeBuilder<Product> builder)
        {
            builder.HasKey(p => p.Id);

            builder.Property(p => p.Title)
                .IsRequired()
                .HasMaxLength(TitleMaxLength);

            builder.Property(p => p.Description)
                .IsRequired()
                .HasMaxLength(DescriptionMaxLength);

            builder.Property(p => p.ImageUrl)
                .IsRequired(false);

            builder.Property(p => p.AuthorId)
                .IsRequired();

            builder.Property(p => p.CreatedOn)
                .IsRequired();

            builder.Property(p => p.CategoryId)
                .IsRequired();

            builder.Property(p => p.IsDeleted)
                .HasDefaultValue(false);

            builder.HasQueryFilter(p => p.IsDeleted == false);

            builder.HasOne(p => p.Author)
                .WithMany()
                .HasForeignKey(p => p.AuthorId)
                .OnDelete(DeleteBehavior.NoAction);

            builder.HasOne(p => p.Category)
                .WithMany(c => c.Products)
                .HasForeignKey(p => p.CategoryId)
                .OnDelete(DeleteBehavior.NoAction);

            builder.HasMany(p => p.UsersProducts)
                .WithOne(up => up.Product)
                .HasForeignKey(up => up.ProductId)
                .OnDelete(DeleteBehavior.NoAction);

            builder.HasData(this.GenerateSeedProducts());
        }

        public List<Product> GenerateSeedProducts()
        {
            return new List<Product>
            {
                new Product
                {
                    Id = 1,
                    Title = "Samsung QLED 55''",
                    Description = "Ultra HD Smart TV with HDR and 120Hz refresh rate.",
                    ImageUrl = "https://example.com/images/samsung-qled.jpg",
                    AuthorId = "df1c3a0f-1234-4cde-bb55-d5f15a6aabcd",
                    CreatedOn = DateTime.Now,
                    CategoryId = 1,
                    IsDeleted = false
                },
                new Product
                {
                    Id = 2,
                    Title = "Dell XPS 15",
                    Description = "Powerful laptop with Intel i7 and 32GB RAM.",
                    ImageUrl = "https://example.com/images/dell-xps.jpg",
                    AuthorId = "df1c3a0f-1234-4cde-bb55-d5f15a6aabcd",
                    CreatedOn = DateTime.Now,
                    CategoryId = 2,
                    IsDeleted = false
                },
                new Product
                {
                    Id = 3,
                    Title = "iPhone 15 Pro",
                    Description = "Latest Apple phone with A17 chip and ProMotion display.",
                    ImageUrl = "https://example.com/images/iphone-15-pro.jpg",
                    AuthorId = "df1c3a0f-1234-4cde-bb55-d5f15a6aabcd",
                    CreatedOn = DateTime.Now,
                    CategoryId = 3,
                    IsDeleted = false
                }
            };
        }
    }
}
