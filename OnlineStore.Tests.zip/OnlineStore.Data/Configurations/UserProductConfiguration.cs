﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OnlineStore.Data.Models;

namespace OnlineStore.Data.Configurations
{
    public class UserProductConfiguration : IEntityTypeConfiguration<UserProduct>
    {
        public void Configure(EntityTypeBuilder<UserProduct> builder)
        {
            builder.HasKey(up => new { up.UserId, up.ProductId });

            builder.HasOne(up => up.User)
                .WithMany()
                .HasForeignKey(up => up.UserId)
                .OnDelete(DeleteBehavior.NoAction);

            builder.HasOne(up => up.Product)
                .WithMany(p => p.UsersProducts)
                .HasForeignKey(up => up.ProductId)
                .OnDelete(DeleteBehavior.NoAction);

            builder.HasQueryFilter(up => up.Product.IsDeleted == false);
        }
    }
}