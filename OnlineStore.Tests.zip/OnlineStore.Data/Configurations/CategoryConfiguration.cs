﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OnlineStore.Data.Models;
using static OnlineStore.GCommon.ValidationConstants.Category;

namespace OnlineStore.Data.Configurations
{
    public class CategoryConfiguration : IEntityTypeConfiguration<Category>
    {
        public void Configure(EntityTypeBuilder<Category> builder)
        {
            builder.HasKey(c => c.Id);

            builder.Property(c => c.Name)
                .IsRequired()
                .HasMaxLength(NameMaxLength);

            builder.HasMany(c => c.Products)
                .WithOne(p => p.Category)
                .HasForeignKey(p => p.CategoryId)
                .OnDelete(DeleteBehavior.NoAction);

            builder.HasData(this.GenerateSeedCategories());
        }

        public List<Category> GenerateSeedCategories()
        {
            return new List<Category>
            {
                new Category { Id = 1, Name = "TV & Monitors" },
                new Category { Id = 2, Name = "Laptops" },
                new Category { Id = 3, Name = "Phones" },
                new Category { Id = 4, Name = "Audio" },
                new Category { Id = 5, Name = "Smart Home" }
            };
        }
    }
}
