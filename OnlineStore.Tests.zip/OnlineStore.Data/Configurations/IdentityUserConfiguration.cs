﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace OnlineStore.Data.Configurations
{
    public class IdentityUserConfiguration : IEntityTypeConfiguration<IdentityUser>
    {
        public void Configure(EntityTypeBuilder<IdentityUser> builder)
        {
           builder.HasData(this.GenerateSeedUser());
        }
        public IdentityUser GenerateSeedUser()
        {
            var defaultUser = new IdentityUser
            {
                Id = "df1c3a0f-1234-4cde-bb55-d5f15a6aabcd",
                UserName = "admin@onlineStore.com",
                NormalizedUserName = "ADMIN@ONLINESTORE.COM",
                Email = "admin@onlineStore.com",
                NormalizedEmail = "ADMIN@ONLINESTORE.COM",
                EmailConfirmed = true,
                PasswordHash = new PasswordHasher<IdentityUser>().HashPassword(
                    new IdentityUser { UserName = "admin@onlineStore.com" },
                    "Admin123!")
            };
            return defaultUser;
           
        }
    }
}
